/*package com.example.medico;

public class Users {
    String fName;
    String lName;
    String mid;
    String email;

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Users(String fName, String lName, String mid, String email, String id, String imageUrl) {
        this.fName = fName;
        this.lName = lName;
        this.mid = mid;
        this.email = email;
        this.id = id;
        this.imageUrl = imageUrl;
    }

    public Users() {
    }

    String id;
    String imageUrl;*/

/*

    public Users(){


    }
    public Users(String fName,String lName,String mid,String email,String id)
    {
        this.fName=fName;
        this.lName=lName;
        this.email=email;
        this.mid=mid;
        this.id=id;
    }

    public String getfName() {
        return fName;
    }

    public String getlName() {
        return lName;
    }

    public String getMid() {
        return mid;
    }

    public String getEmail() {
        return email;
    }
    public String getId(){
        return id;
    }

}*/

